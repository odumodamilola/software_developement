<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Progress</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="shortcut icon" href="<?php echo e(asset('images/eduflow.png')); ?>" type="image/x-icon">

    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-gray-100 font-sans">
    <!-- resources/views/dashboard.blade.php -->
<!-- resources/views/documents.blade.php -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="flex mt-5">
        <!-- Sidebar -->
        <aside class="bg-green-600 text-white w-64 p-4 space-y-6 hidden md:block">
          
            <a href="<?php echo e(route('documents')); ?>" class="flex items-center space-x-2 text-green-400">
                <i class="fas fa-file-alt"></i>
                <span>Documents</span>
            </a>
            <a href="#" class="flex items-center space-x-2">
                <i class="fas fa-graduation-cap"></i>
                <span>Final Year Clearance</span>
            </a>
            <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center space-x-2">
                <i class="fas fa-user-edit"></i>
                <span>Edit Profile</span>
            </a>
            <a href="<?php echo e(route('profile.settings')); ?>" class="flex items-center space-x-2">
                <i class="fas fa-cog"></i>
                <span>Accounts Settings</span>
            </a>
        </aside>

        <!-- Main Documents Content -->
<main class="flex-1 p-6">
    <h2 class="text-2xl font-semibold text-gray-700 mb-4">My Documents</h2>
    
    
    <!-- Display success or error messages -->
    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline"><?php echo e(session('success')); ?></span>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Error!</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Flex Container for Documents and Upload Form -->
    <div class="flex flex-col gap-6">
        <!-- Document Upload Form -->
        <div class="p-4 bg-white border border-gray-200 rounded shadow-sm flex flex-col items-center">
            <form action="<?php echo e(route('documents.upload')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label for="upload" class="cursor-pointer w-24 h-24 bg-gray-100 flex items-center justify-center rounded mb-2 hover:bg-gray-200">
                    <i class="fas fa-upload text-gray-400 text-4xl"></i>
                </label>
                <input type="file" id="upload" name="document" class="hidden" onchange="this.form.submit()">
                <p class="text-center text-gray-700">Upload a document</p>
            </form>
        </div>
        <!-- Document Items -->
        <div class="flex-1">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-4 bg-white border border-gray-200 rounded shadow-sm flex flex-col items-center">
                        <div class="w-24 h-24 bg-gray-100 flex items-center justify-center rounded mb-2">
                            <i class="fas fa-file-alt text-gray-400 text-4xl"></i>
                        </div>
                        <p class="text-center text-gray-700"><?php echo e($document->file_name); ?></p>
                        <a href="<?php echo e(Storage::url($document->file_path)); ?>" class="text-blue-600 hover:underline mt-2">View</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>









   
</body>

</html>
<?php /**PATH /home/damilolapeace/Documents/Spotlight Tech/Software Developement/Website Development/Backend/Laravel/eduflow/resources/views/documents.blade.php ENDPATH**/ ?>