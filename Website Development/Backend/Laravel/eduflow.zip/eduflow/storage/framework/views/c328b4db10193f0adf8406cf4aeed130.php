<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Progress</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>

<body class="bg-gray-100 font-sans">
    <?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="flex flex-col md:flex-row">
            <!-- Sidebar -->
            <aside class="bg-green-600 text-white w-64 p-4 space-y-6 hidden md:block">
          
                <a href="<?php echo e(route('documents')); ?>" class="flex items-center space-x-2 text-green-400">
                    <i class="fas fa-file-alt"></i>
                    <span>Documents</span>
                </a>
                <a href="#" class="flex items-center space-x-2">
                    <i class="fas fa-graduation-cap"></i>
                    <span>Final Year Clearance</span>
                </a>
                <a href="<?php echo e(route('profile.edit')); ?>" class="flex items-center space-x-2">
                    <i class="fas fa-user-edit"></i>
                    <span>Edit Profile</span>
                </a>
                <a href="<?php echo e(route('profile.settings')); ?>" class="flex items-center space-x-2">
                    <i class="fas fa-cog"></i>
                    <span>Accounts Settings</span>
                </a>
            </aside>

            <!-- Main content -->
            <div class="w-full md:w-3/4 p-4">
                <!-- Profile section -->
                <div class="flex items-center mb-4">
                    <?php if(Auth::user()->profile_picture): ?>
                        <img src="<?php echo e(asset('storage/' . Auth::user()->profile_picture)); ?>" alt="Profile Picture" class="rounded-full w-24 h-24 object-cover">
                    <?php else: ?>
                        <div class="rounded-full bg-green-300 w-24 h-24"></div>
                    <?php endif; ?>
                    <div class="ml-4">
                        <h2 class="text-xl font-bold"><?php echo e(Auth::user()->name); ?></h2>
                        <p class="text-gray-600">Computer Science</p>
                    </div>
                </div>
                <div class="p-4 sm:p-8 bg-white dark:bg-gray-800 shadow sm:rounded-lg">
                    <div class="max-w-xl">
                        <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH /home/damilolapeace/Documents/Spotlight Tech/Software Developement/Website Development/Backend/Laravel/eduflow/resources/views/profile/edit.blade.php ENDPATH**/ ?>